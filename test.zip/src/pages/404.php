<div class="row">
    <div class="col-md-6 offset-md-3 text-center">
        <h1 class="display-1">404</h1>
        <h2>Page Not Found</h2>
        <p>Sorry, the page you are looking for does not exist.</p>
        <a href="index.php" class="btn btn-primary">Go to Dashboard</a>
    </div>
</div>